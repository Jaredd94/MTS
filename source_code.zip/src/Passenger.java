
public class Passenger {
	public Passenger() {
		
	}
}
