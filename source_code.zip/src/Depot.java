
public class Depot extends Stop{
	
	public Depot(int id, String name, double latitude, double longitude) {
		super(id, name, 0, latitude, longitude);
	}
	
}
